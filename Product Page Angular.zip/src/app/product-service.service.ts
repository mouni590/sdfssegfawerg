import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductPage } from 'src/page';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
 
  constructor(private httpClient:HttpClient) { 

  }
 
 
 
  getall(){
    return this.httpClient.get<ProductPage[]>('http://localhost:8081/get');
  }
  getProduct(id:string){
    return this.httpClient.get<ProductPage[]>('http://localhost:8081/get'+'/'+id);

  }
}
