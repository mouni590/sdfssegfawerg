import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductPageComponent } from './product-page/product-page.component';
import { combineAll } from 'rxjs/operators';
import { WishListComponent } from './wish-list/wish-list.component';
import { CartComponent } from './cart/cart.component';
import { BuyNowComponent } from './buy-now/buy-now.component';


const routes: Routes = [
  {
    path:'',
    component:ProductListComponent
  },
  {
    path:'prod/:id',
    component:ProductPageComponent
  },
  {
    path:'wishlist',
    component:WishListComponent
  },
  {
    path:'cart',
    component:CartComponent
  },
  {
    path:'payment',
    component:BuyNowComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
