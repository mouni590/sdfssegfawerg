import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { ProductPage } from 'src/page';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  array:ProductPage[];
  constructor( private proser:ProductServiceService) { }

  ngOnInit() {
    this.proser.getall().subscribe(data=>this.handleSuccessfulResponse(data));
    
  }
  

  handleSuccessfulResponse(response)
  {
      this.array=response;
      console.log(this.array)

  }
}
