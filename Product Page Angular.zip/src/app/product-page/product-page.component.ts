import { Component, OnInit } from '@angular/core';
import { ProductPage } from 'src/page';
import { ProductServiceService } from '../product-service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent implements OnInit {
  array:ProductPage[];
  constructor(private route:ActivatedRoute,private productservice:ProductServiceService) { }
  
  ngOnInit() {
    const param=this.route.snapshot.paramMap.get('id');
    if(param){
      this.getProduct(param);
    }
  }
  getProduct(id:string) {
    console.log(id)
    this.productservice.getProduct(id).subscribe(
      product=>this.array=product
    );
  }
}
