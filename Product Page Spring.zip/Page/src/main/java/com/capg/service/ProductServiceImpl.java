package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Product;
import com.capg.dao.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService  {

	@Autowired
	ProductRepository daoobject;
	
	@Override
	public Product getDetailsById(String id) {
		// TODO Auto-generated method stub
		return daoobject.findById(id).get();
	}

	@Override
	public List<Product> getDetails() {
		// TODO Auto-generated method stub
		return daoobject.findAll();
	}

}
