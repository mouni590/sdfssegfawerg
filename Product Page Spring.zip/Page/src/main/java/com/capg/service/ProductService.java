package com.capg.service;

import java.util.List;

import com.capg.bean.Product;

public interface ProductService {

	public Product getDetailsById(String id);
	public List<Product> getDetails();
}
