package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Product;
import com.capg.service.ProductService;

@CrossOrigin("http://localhost:4200")
@RestController
public class ProductController {
	@Autowired
	ProductService serviceobj;
	
	@RequestMapping("/get/{id}")
	public Product getDetailsByUsername(@PathVariable String id){
		return serviceobj.getDetailsById(id);
	}
	@GetMapping("/get")
	public List<Product> getDetails(){
		return serviceobj.getDetails();
	}
	
}
